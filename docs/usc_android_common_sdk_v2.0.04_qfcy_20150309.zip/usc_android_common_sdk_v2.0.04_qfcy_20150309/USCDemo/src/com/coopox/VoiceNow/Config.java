/**
 * Config.java [V 1.0.0]
 * classes : cn.yunzhisheng.prodemo.Config
 * liujunjie Create  at 2015-1-9  ??4:30:32
 */
package com.coopox.VoiceNow;

/**
 * cn.yunzhisheng.prodemo.Config
 * @author  liujunjie <br/>
 * Create at 2015-1-9 ??4:30:32
 *
 */
public class Config {
	
	public static final String appKey = "tryvse7h434cdwrkil6zgynnbu4hjarljttmwpit";
	public static final String  secret = "1846fe35f0d01ac8395c6c523852cff3";

}
