package com.coopox.VoiceNow;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.coopox.VoiceNow.R;
import cn.yunzhisheng.tts.offline.TTSPlayerListener;
import cn.yunzhisheng.tts.offline.basic.ITTSControl;
import cn.yunzhisheng.tts.offline.basic.TTSFactory;

public class TTSOfflineActivity extends Activity implements OnClickListener {


	private int AsrType = ASR_ONLINE_TYPE;
	private static boolean TTS_PLAY_FLAGE = false;
	public static final int ASR_ONLINE_TYPE = 0;
	public static final int ASR_OFFLINE_TYPE = 1;
	public static final int WAKEUP_OFFLINE_TYPE = 2;
	public static final int TTS_OFFLINE_TYPE = 3;


	private EditText mTTSText;
	private TextView mTextViewTip;
	private TextView mTextViewStatus;
	private Button mTTSPlayBtn;

	private ITTSControl mTTSPlayer;
	private Dialog mFunctionDialog;

	private ImageView mFunctionButton;// 选择功能

	@Override
	public void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_offline_tts);
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE,
				R.layout.status_bar_main);

		mTTSText = (EditText) findViewById(R.id.textViewResult);
		mTextViewStatus = (TextView) findViewById(R.id.textViewStatus);
		mTextViewTip = (TextView) findViewById(R.id.textViewTip);
		mTTSPlayBtn = (Button) findViewById(R.id.recognizer_btn);

		mFunctionButton = (ImageView) findViewById(R.id.function_button);
		mFunctionButton.setOnClickListener(this);
//		mLogoImageView = (ImageView) findViewById(R.id.logo_imageview);
		mTTSPlayBtn.setEnabled(false);
		// 功能选择
		mFunctionDialog = new Dialog(this, R.style.dialog);
		mFunctionDialog.setContentView(R.layout.function_list_item);
		mFunctionDialog.findViewById(R.id.asr_online_text).setOnClickListener(this);
		mFunctionDialog.findViewById(R.id.asr_offline_text).setOnClickListener(this);
		mFunctionDialog.findViewById(R.id.wakeup_offline_text).setOnClickListener(this);
		mFunctionDialog.findViewById(R.id.tts_offline_text).setOnClickListener(this);

		mTTSPlayBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
               TTSPlay();
			}
		});

		// 初始化本地TTS播报
		initTts();
	}


	/**
	 * 初始化本地离线TTS
	 */
	private void initTts() {

		// 初始化语音合成对象
		mTTSPlayer = TTSFactory.createTTSControl(this, Config.appKey);
		// 设置回调监听
		mTTSPlayer.setTTSListener(new TTSPlayerListener() {

			@Override
			public void onPlayEnd() {
				// 播放完成回调
				log_i("onPlayEnd");
                setTTSButtonReady();
			}

			@Override
			public void onPlayBegin() {
				// 开始播放回调
				log_i("onPlayBegin");
			}

			@Override
			public void onInitFinish() {
				// 初始化成功回调
				log_i("onInitFinish");
				mTTSPlayBtn.setEnabled(true);
			}

			@Override
			public void onError(cn.yunzhisheng.tts.offline.common.USCError arg0) {
				// 语音合成错误回调
				log_i("onError");
				toastMessage(arg0.toString());
				setTTSButtonReady();
			}

			@Override
			public void onCancel() {
				// 取消播放回调
				log_i("onCancel");
			}

			@Override
			public void onBuffer() {
				// 开始缓冲回调
				log_i("onBuffer");

			}
		});
		// 初始化合成引擎
		mTTSPlayer.init();
	}


	private void TTSPlay(){
	     if (!TTS_PLAY_FLAGE){
         		mTTSPlayer.play(mTTSText.getText().toString());
         		setTTSButtonStop();
         }else{
         	mTTSPlayer.stop();
         	setTTSButtonReady();
         }
		
	}
	
	private void setTTSButtonStop(){
 		TTS_PLAY_FLAGE = true;
 		mTTSPlayBtn.setText(R.string.stop_tts);
	}
	
	private void setTTSButtonReady(){
		mTTSPlayBtn.setText(R.string.start_tts);
		TTS_PLAY_FLAGE = false;
	}
	protected void setTipText(String tip) {

		mTextViewTip.setText(tip);
	}

	protected void setStatusText(String status) {

		mTextViewStatus.setText(getString(R.string.lable_status) + "(" + status
				+ ")");
	}


	@Override
	public void onPause() {
		super.onPause();
		// 主动停止识别
	}

	private void log_i(String log) {
		Log.i("demo", log);
	}

	@Override
	protected void onDestroy() {
		// 主动释放离线引擎
		mTTSPlayer.release();
		super.onDestroy();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {

		case R.id.function_button:
			mFunctionDialog.show();
			break;
		case R.id.asr_online_text:
			AsrType = ASR_ONLINE_TYPE;
			changeView();
			break;
		case R.id.asr_offline_text:
			AsrType = ASR_OFFLINE_TYPE;
			changeView();
			break;
		case R.id.wakeup_offline_text:
			AsrType = WAKEUP_OFFLINE_TYPE;
			changeView();
			break;
		case R.id.tts_offline_text:
			AsrType = TTS_OFFLINE_TYPE;
			changeView();
			break;
		default:
			break;
		}

	}

	private void changeView() {
		if(AsrType == TTS_OFFLINE_TYPE){
			Intent intent = new Intent(this,TTSOfflineActivity.class);
			this.startActivity(intent);
			this.finish();
		}
		else if (AsrType == ASR_ONLINE_TYPE) {
			Intent intent = new Intent(this, MainActivity.class);
			this.startActivity(intent);
			this.finish();
		} 
		else if(AsrType == WAKEUP_OFFLINE_TYPE){
			Intent intent = new Intent(this,WakeupOfflineActivity.class);
			this.startActivity(intent);
			this.finish();
		}
		mFunctionDialog.dismiss();
	}
	
	private void toastMessage(String message) {
		Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
	}
}
